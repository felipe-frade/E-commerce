<header id="header" class="alt">
	<h1><a href="index.php">Spectral</a></h1>
	<nav id="nav">
		<ul>
			<li class="special">
				<a href="#menu" class="menuToggle"><span>Menu</span></a>
				<div id="menu">
					<ul>
						<li><a href="index.php?page=home">Home</a></li>
						<li id="abre-sub-menu">
							<a>Products</a>
							<ul class="sub-menu">
								<li><a href="index.php?page=products-fisico">Shop</a></li>
								<li><a href="index.php?page=products-usado">Usados</a></li>
								<li><a href="index.php?page=products-ebook">E-book</a></li>
							</ul>
						</li>
						<li><a href="index.php?page=elements">Description</a></li>
						<li><a href="index.php?page=about">About</a></li>
					</ul>
				</div>
			</li>
		</ul>
	</nav>
</header>