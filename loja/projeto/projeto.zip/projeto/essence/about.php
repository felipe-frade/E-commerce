<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Essence - Fashion Ecommerce Template</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css/core-style.css">
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- ##### menu e menu (header.php) ##### -->
    <?php include "header.php"?>
    <!-- ##### menu e menu (header.php) ##### -->

    <!-- ##### Welcome Area Start ##### -->
    <section class="welcome_area about_area bg-img background-overlay" style="background-image: url(img/core-img/about.jpg);">
        <div class="container h-100">
            
        </div>
    </section>
    <!-- ##### Welcome Area End ##### -->

    <!-- ##### about ##### -->
    <section class="about_area section-padding-80 clearfix">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a iaculis nunc. Proin id diam elementum, fermentum lacus id, efficitur metus. Aliquam facilisis dignissim massa, quis congue dolor efficitur eu. Donec suscipit vestibulum ligula, id hendrerit erat pellentesque at.</h2>
                </div>
            </div>
        </div>
    </section>

    <!-- ##### footer (footer.php) ##### -->
    <?php include "footer.php"?>
    <!-- ##### footer (footer.php) ##### -->

</body>

</html>