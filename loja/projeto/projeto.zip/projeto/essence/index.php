<?php
    if(isset($_GET['pg']) AND !empty($_GET['pg'])){
        $pag = $_GET['pg'];
    }else {
        $pag = 'home';
    }

    $nome = 'leo';

    include_once($pag.'.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    
</head>
<body>
    <h2>Ops. Page not found!</h2>
</body>

</html>