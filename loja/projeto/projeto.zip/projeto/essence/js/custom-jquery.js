(function ($) {
    'use strict';

    var $window = $(window);

    // exemplo
    // // :: Nav Active Code
    // if ($.fn.classyNav) {
    //     $('#essenceNav').classyNav();
    // }

    // // :: PreventDefault a Click
    // $("a[href='#']").on('click', function ($) {
    //     $.preventDefault();
    // });

    if ($('')) {}

})(jQuery);